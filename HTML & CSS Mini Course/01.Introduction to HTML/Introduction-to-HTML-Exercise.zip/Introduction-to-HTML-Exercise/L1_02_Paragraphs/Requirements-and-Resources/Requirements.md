﻿# 02 - Paragraphs
------
Problems for homework for the [“HTML and CSS Basics”](#) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/#!/List/ByCategory/165/HTML-and-CSS)

## Constraints
* Change the document **title**
* Use **h1** tag for the title
* Use **p** tag to create the paragraphs
* See the provided screenshot and use **strong** and em **tags** where needed



