﻿# 07 - Article Page
------
Problems for homework for the [“HTML and CSS Basics”](#) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/#!/List/ByCategory/165/HTML-and-CSS)

## Constraints
* Create an **"index.html"** and **"style.css"** files
* Change the document **title** to *"Article Page"*
* Create a **header** with **paragraph** inside for the site title
* Use **main** tag for the page main content
	* Add an **article** inside
* Use **aside** tag for the sidebar
	* Add two **sections** inside
	