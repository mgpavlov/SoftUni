//<minTestCount>7</minTestCount> - specifies the minimum amount of tests your code should have.
var StringBuilder = function () {};