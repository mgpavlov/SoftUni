package p04SayHelloExtend;

public class European extends BasePerson {
    public European(String name) {
        super(name);
    }
}
