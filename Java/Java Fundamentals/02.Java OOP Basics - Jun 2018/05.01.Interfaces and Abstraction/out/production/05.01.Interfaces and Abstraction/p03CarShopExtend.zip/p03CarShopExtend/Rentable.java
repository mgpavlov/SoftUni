package p03CarShopExtend;

public interface Rentable extends Car {
    int getMinRentDay();
    Double getPricePerDay();
}
