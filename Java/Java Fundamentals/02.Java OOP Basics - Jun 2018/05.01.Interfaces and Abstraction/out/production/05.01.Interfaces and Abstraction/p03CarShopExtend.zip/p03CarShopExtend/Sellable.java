package p03CarShopExtend;

public interface Sellable extends Car{
    double getPrice();

}
