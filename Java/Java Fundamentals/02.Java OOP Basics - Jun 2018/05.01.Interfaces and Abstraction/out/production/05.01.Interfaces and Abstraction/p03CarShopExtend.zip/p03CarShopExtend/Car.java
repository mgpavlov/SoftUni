package p03CarShopExtend;

public interface Car {
    Integer TIRES = 4;

    String getModel();
    String getColor();
    Integer  getHorsePower();

}
