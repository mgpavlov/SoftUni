package p04SayHelloExtend;

public interface Person {
    String getName();
    String sayHello();
}
