package p04SayHelloExtend;

public class Chinese extends BasePerson {
    Chinese(String name) {
        super(name);
    }
    @Override
    public String sayHello() {
        return "Djydjybydjy";
    }
}
