package p05OnlineRadioDatabase;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(reader.readLine());
        List<Song> songs = new ArrayList<>();

        while (n-- > 0) {
            String[] input = reader.readLine().split("[;:]");
            String artist = input[0];
            String songName = input[1];
            int minutes = Integer.valueOf(input[2]);
            int seconds = Integer.valueOf(input[3]);
            /*int songLength = minutes * 60 + seconds;*/
            Song song = null;
            try {
                song = new Song(artist, songName, minutes, seconds);
                songs.add(song);
                System.out.println("Song added.");
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
            }
        }
        System.out.printf("Songs added: %d%n", songs.size());
        long totalLength = songs.stream().mapToLong(song->song.getSongLength(song.getMinutes(), song.getSeconds())).sum();
        System.out.println(Result(songs, totalLength));
    }
    private static String Result(List<Song> songs, long totalLength) {
        long h = totalLength/3600;
        long temp = totalLength%3600;
        long min = temp/60;
        long sec = temp%60;
        return String.format("Playlist length: %dh %dm %ds", h, min, sec);
    }
}
