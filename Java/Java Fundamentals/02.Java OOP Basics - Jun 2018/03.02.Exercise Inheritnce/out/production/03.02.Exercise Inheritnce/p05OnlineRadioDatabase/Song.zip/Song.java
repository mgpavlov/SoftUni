package p05OnlineRadioDatabase;

public class Song {
    private String artist;
    private String name;
    private long minutes;
    private long seconds;


    public Song(String artist, String songName, long minutes, long seconds) {
        this.setArtist(artist);
        this.setName(songName);
        this.setMinutes(minutes);
        this.setSeconds(seconds);
    }

    public String getArtist() {
        return this.artist;
    }

    private void setArtist(String artist) {
        if (artist.length()<3||artist.length()>20){
            throw new IllegalArgumentException("Artist name should be between 3 and 20 symbols.");
        }
        this.artist = artist;
    }

    public String getName() {
        return this.name;
    }

    private void setName(String name) {
        if (name.length()<3||name.length()>30){
            throw new IllegalArgumentException("Song name should be between 3 and 30 symbols.");
        }
        this.name = name;
    }


    public long getSongLength(long minutes, long seconds) {
        long songLength = minutes * 60 + seconds;
        if (songLength > 899 || songLength < 0){
            throw new IllegalArgumentException("Invalid song length");
        }
        return songLength;
    }
    public long getMinutes() {
        return this.minutes;
    }

    private void setMinutes(long minutes) {
        if (minutes > 14 || minutes < 0){
            throw new IllegalArgumentException("Invalid song length.\nSong minutes should be between 0 and 14.");
        }
        this.minutes = minutes;
    }

    public long getSeconds() {
        return this.seconds;
    }

    private void setSeconds(long seconds) {
        if (seconds > 59 || seconds < 0){
            throw new IllegalArgumentException("Song seconds should be between 0 and 59.");
        }
        this.seconds = seconds;
    }
}
