package p05OnlineRadioDatabase4;

public class InvalidSongException extends Exception {

    public InvalidSongException() {
    }

    public InvalidSongException(String message) {
        super(message);
    }
}
