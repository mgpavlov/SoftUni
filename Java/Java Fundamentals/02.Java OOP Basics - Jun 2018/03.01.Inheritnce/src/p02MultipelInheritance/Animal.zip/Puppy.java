package p02MultipelInheritance;

public class Puppy extends Dog {
    public void weep(){
        System.out.println("weeping...");
    }
}
