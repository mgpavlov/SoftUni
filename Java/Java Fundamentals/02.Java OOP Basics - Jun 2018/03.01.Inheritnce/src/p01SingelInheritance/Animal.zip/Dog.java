package p01SingelInheritance;

public class Dog extends Animal {
    void bark(){
        System.out.println("barking...");
    }
}
