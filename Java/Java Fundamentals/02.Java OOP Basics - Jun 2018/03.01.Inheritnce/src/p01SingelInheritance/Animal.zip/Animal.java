package p01SingelInheritance;

public class Animal {
    public void eat(){
        System.out.println("eating...");
    }
}
