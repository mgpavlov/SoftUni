package p04FragileBaseClass;

public class Food {
}
