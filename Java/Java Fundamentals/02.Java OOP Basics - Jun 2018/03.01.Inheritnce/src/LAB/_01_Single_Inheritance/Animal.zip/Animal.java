package _03_Inheritance.LAB._01_Single_Inheritance;

public class Animal {
    public void eat(){
        System.out.println("eating…");
    }
}
