package _03_Inheritance.LAB._01_Single_Inheritance;

public class Dog extends Animal {

    void bark(){
        System.out.println("barking…");
    }
}
