package _03_Inheritance.LAB._03_Hierarchical_Inheritance;

public class Cat extends Animal {
    public void meow(){
        System.out.printf("meowing…%n");
    }
}
