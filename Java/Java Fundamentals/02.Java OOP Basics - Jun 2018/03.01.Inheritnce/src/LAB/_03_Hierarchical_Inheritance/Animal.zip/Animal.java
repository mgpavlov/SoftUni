package _03_Inheritance.LAB._03_Hierarchical_Inheritance;

public class Animal {
    public void eat(){
        System.out.printf("eating…%n");
    }
}
