package _03_Inheritance.LAB._03_Hierarchical_Inheritance;

public class Dog extends Animal {
    public void bark(){
        System.out.printf("barking…%n");
    }
}
