package _03_Inheritance.LAB._04_Fragile_Base_Class;

public class Food {
}
