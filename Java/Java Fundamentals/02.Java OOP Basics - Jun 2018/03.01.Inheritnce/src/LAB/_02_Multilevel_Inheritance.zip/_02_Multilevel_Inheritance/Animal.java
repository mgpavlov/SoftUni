package _03_Inheritance.LAB._02_Multilevel_Inheritance;

public class Animal {
    public void eat(){
        System.out.println("eating…");
    }
}
