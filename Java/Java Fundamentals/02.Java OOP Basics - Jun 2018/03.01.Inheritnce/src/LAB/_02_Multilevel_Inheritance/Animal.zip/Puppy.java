package _03_Inheritance.LAB._02_Multilevel_Inheritance;

public class Puppy extends Dog {
    public void weep() {
        System.out.printf("weeping…");
    }
}
