package p01Vehicles;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String[] carInfo = reader.readLine().split("\\s+");
        double carFuelQuantity = Double.parseDouble(carInfo[1]);
        double carLitersPerKm = Double.parseDouble(carInfo[2]);
        Vehicles car = new Car(carFuelQuantity, carLitersPerKm);

        String[] truckInfo = reader.readLine().split("\\s+");
        double truckFuelQuantity = Double.parseDouble(truckInfo[1]);
        double truckLitersPerKm = Double.parseDouble(truckInfo[2]);
        Vehicles truck = new Truck(truckFuelQuantity, truckLitersPerKm);

        int n = Integer.parseInt(reader.readLine());
        DecimalFormat df = new DecimalFormat("#.##");
        while (n-- > 0) {
            String[] input = reader.readLine().split("\\s+");
            switch (input[0]) {
                case "Drive":
                    double distance = Double.parseDouble(input[2]);
                    switch (input[1]) {
                        case "Car":
                            if (!car.drive(distance)) {
                                System.out.println("Car needs refueling");
                            } else {
                                System.out.printf("Car travelled %s km%n", df.format(distance));
                            }
                            break;
                        case "Truck":
                            if (!truck.drive(distance)) {
                                System.out.println("Truck needs refueling");
                            } else {
                                System.out.printf("Truck travelled %s km%n", df.format(distance));
                            }
                            break;
                        default:

                            break;
                    }
                    break;
                case "Refuel":
                    double fuel = Double.parseDouble(input[2]);
                    switch (input[1]) {
                        case "Car":
                            car.refuel(fuel);
                            break;
                        case "Truck":
                            truck.refuel(fuel);
                            break;
                        default:

                            break;
                    }

                    break;
                default:

                    break;
            }
        }

        System.out.printf("Car: %.2f%n", car.getFuelQuantity());
        System.out.printf("Truck: %.2f%n", truck.getFuelQuantity());
    }
}
