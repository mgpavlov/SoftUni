package polymorphysm.exercises.wild_farm.food;

public class Meat extends Food {
  
  public Meat(int quantity, String foodType) {
    super(quantity, foodType);
  }
  
}
