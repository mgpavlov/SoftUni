package p03WildFarm.food;

public class Vegetable extends Food {
  
  public Vegetable(int quantity, String foodType) {
    super(quantity, foodType);
  }
  
}
