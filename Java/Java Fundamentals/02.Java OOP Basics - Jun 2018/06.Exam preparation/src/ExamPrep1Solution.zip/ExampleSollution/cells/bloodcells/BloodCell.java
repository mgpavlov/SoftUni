package ExampleSollution.cells.bloodcells;


import ExampleSollution.cells.Cell;

public abstract class BloodCell extends Cell {

    public BloodCell(String id, int health, int positionX, int positionY) {
        super(id, health, positionX, positionY);
    }

}
