package ExamPrep4.colonists.engineers;

import ExamPrep4.colonists.Colonist;

public abstract class Engineer extends Colonist {
    public Engineer(String id, String familyId, int talent, int age) {
        super(id, familyId, talent, age);
    }
}
