package ExamPrep4;

public class Family {
    private String id;
    public Family(String id) {
        this.id = id;
    }
    public String getId() {
        return this.id;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
