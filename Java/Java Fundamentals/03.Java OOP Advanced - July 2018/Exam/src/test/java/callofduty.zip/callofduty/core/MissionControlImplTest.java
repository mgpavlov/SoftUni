package callofduty.core;

import callofduty.domain.missions.EscortMission;
import callofduty.domain.missions.HuntMission;
import callofduty.domain.missions.SurveillanceMission;
import callofduty.interfaces.MissionControl;
import org.junit.Assert;
import org.junit.Test;

import java.lang.reflect.InvocationTargetException;

import static org.junit.Assert.*;

public class MissionControlImplTest {

    @Test
    public void generateMission1() throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
        MissionControl missionControl = new MissionControlImpl();
        EscortMission escortMission = (EscortMission) missionControl.generateMission("a", 1.0, 1.0);
        Assert.assertEquals(escortMission.getRating(), 1.0, Double.MIN_VALUE);
        Assert.assertEquals(escortMission.getBounty(),1.0, Double.MIN_VALUE);
        Assert.assertEquals(escortMission.getId(), "a");

    }

    @Test
    public void generateMission2() throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
        MissionControl missionControl = new MissionControlImpl();
        HuntMission huntMission = (HuntMission) missionControl.generateMission("a", 1.0, 1.0);
        Assert.assertEquals(huntMission.getRating(), 1.0, Double.MIN_VALUE);
        Assert.assertEquals(huntMission.getBounty(),1.0, Double.MIN_VALUE);
        Assert.assertEquals(huntMission.getId(), "a");
    }

    @Test
    public void generateMission3() throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
        MissionControl missionControl = new MissionControlImpl();
        SurveillanceMission surveillanceMission = (SurveillanceMission) missionControl.generateMission("a", 1.0, 1.0);
        Assert.assertEquals(surveillanceMission.getRating(), 1.0, Double.MIN_VALUE);
        Assert.assertEquals(surveillanceMission.getBounty(),1.0, Double.MIN_VALUE);
        Assert.assertEquals(surveillanceMission.getId(), "a");
    }
}