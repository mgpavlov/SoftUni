package cresla.entities.modules;

public class HeatProcessor extends AbstractAbsorbingModule {
    public HeatProcessor(int heatAbsorbing) {
        super(heatAbsorbing);
    }
}
