package cresla.entities.modules;

public class CooldownSystem extends AbstractAbsorbingModule {
    public CooldownSystem(int heatAbsorbing) {
        super(heatAbsorbing);
    }
}
