package panzer.models.miscellaneous;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import panzer.contracts.*;

import java.math.BigDecimal;

import static org.junit.Assert.*;

public class VehicleAssemblerTest {
    private Assembler assembler;
    @Before
    public void setUp() throws Exception {
        assembler = new VehicleAssembler();

        Part part1 = Mockito.mock(AttackModifyingPart.class);
        Part part2 = Mockito.mock(DefenseModifyingPart.class);
        Part part3 = Mockito.mock(HitPointsModifyingPart.class);

        Mockito.when(part1.getPrice()).thenReturn(BigDecimal.valueOf(Long.MAX_VALUE));
        Mockito.when(part2.getPrice()).thenReturn(BigDecimal.valueOf(Long.MAX_VALUE));
        Mockito.when(part3.getPrice()).thenReturn(BigDecimal.valueOf(Long.MAX_VALUE));

        Mockito.when(part1.getWeight()).thenReturn(10.00);
        Mockito.when(part2.getWeight()).thenReturn(11.00);
        Mockito.when(part3.getWeight()).thenReturn(12.00);

        Mockito.when(part1.getModel()).thenReturn("A");
        Mockito.when(part2.getModel()).thenReturn("B");
        Mockito.when(part3.getModel()).thenReturn("C");

        Mockito.when(((AttackModifyingPart) part1).getAttackModifier()).thenReturn(10);
        Mockito.when(((DefenseModifyingPart) part2).getDefenseModifier()).thenReturn(10);
        Mockito.when(((HitPointsModifyingPart) part3).getHitPointsModifier()).thenReturn(10);


        this.assembler.addArsenalPart(part1);
        this.assembler.addShellPart(part2);
        this.assembler.addEndurancePart(part3);


    }


    @Test
    public void getTotalWeight() {
        Assert.assertEquals(this.assembler.getTotalWeight(), 33, 0.1);
        Assert.assertEquals(this.assembler.getTotalPrice(), BigDecimal.valueOf(Long.MAX_VALUE).multiply(BigDecimal.valueOf(3)));
        Assert.assertEquals(this.assembler.getTotalAttackModification(), 10);
        Assert.assertEquals(this.assembler.getTotalDefenseModification(), 10);
        Assert.assertEquals(this.assembler.getTotalHitPointModification(), 10);
    }

    @Test
    public void getTotalPrice() {
    }

    @Test
    public void getTotalAttackModification() {
    }

    @Test
    public void getTotalDefenseModification() {
    }

    @Test
    public void getTotalHitPointModification() {
    }

    @Test
    public void addArsenalPart() {
    }

    @Test
    public void addShellPart() {
    }

    @Test
    public void addEndurancePart() {
    }
}