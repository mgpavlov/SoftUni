package app.contracts;

public interface Writer {

    void writeLine(String text);
}
