package app.models.specialties;

public class Toughness extends AbstractSpecialty {

    @Override
    public int getToughnessBonus() {
        return super.getBonus();
    }
}
