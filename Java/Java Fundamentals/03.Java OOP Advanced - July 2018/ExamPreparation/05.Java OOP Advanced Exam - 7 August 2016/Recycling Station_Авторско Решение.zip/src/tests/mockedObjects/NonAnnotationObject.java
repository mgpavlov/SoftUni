package tests.mockedObjects;


public class NonAnnotationObject {
}
