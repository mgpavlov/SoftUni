package main.contracts.ui;


public interface Writer {
    void writeLine(String message);
}
