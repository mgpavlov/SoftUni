package main.contracts;


public interface Runnable {
    void run();
}
