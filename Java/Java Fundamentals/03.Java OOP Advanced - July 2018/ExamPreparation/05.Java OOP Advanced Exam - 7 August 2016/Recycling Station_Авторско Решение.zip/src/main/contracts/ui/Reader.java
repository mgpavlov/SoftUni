package main.contracts.ui;


public interface Reader {
    String readLine();
}
