package app.contracts;

public interface Hero extends Character, Targetable {

    int getStrength();

    int getDexterity();

    int getIntelligence();




}
