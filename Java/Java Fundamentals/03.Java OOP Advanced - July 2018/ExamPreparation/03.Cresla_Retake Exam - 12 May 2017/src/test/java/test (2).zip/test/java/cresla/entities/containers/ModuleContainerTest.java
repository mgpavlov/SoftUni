package test.java.cresla.entities.containers;

import cresla.entities.containers.ModuleContainer;
import cresla.interfaces.AbsorbingModule;
import cresla.interfaces.EnergyModule;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ModuleContainerTest {
    private ModuleContainer moduleContainer;
    private EnergyModule energyModule;
    private AbsorbingModule absorbingModule1;
    private AbsorbingModule absorbingModule2;
    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void addEnergyModule() {
    }

    @Test
    public void addAbsorbingModule() {
    }

    @Test
    public void getTotalEnergyOutput() {
    }

    @Test
    public void getTotalHeatAbsorbing() {
    }
}