package test.java.cresla.entities.containers;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ModuleContainerTest {

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void addEnergyModule() {
    }

    @Test
    public void addAbsorbingModule() {
    }

    @Test
    public void getTotalEnergyOutput() {
    }

    @Test
    public void getTotalHeatAbsorbing() {
    }
}