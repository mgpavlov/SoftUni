package cresla.entities.modules.energyModules;

public class CryogenRod extends EnergyModuleAbstract{
    public CryogenRod(/*int id, */int energyOutput) {
        super(/*id, */energyOutput);
    }
}
