package cresla.entities.modules.absorberModules;

public class HeatProcessor extends AbsorbingModuleAbstract{

    public HeatProcessor(/*int id, */int heatAbsorbing) {
        super(/*id, */heatAbsorbing);
    }
}
