package cresla.entities.modules;

import cresla.entities.AbstractIdentifiable;
import cresla.interfaces.Module;

public class AbstractModule extends AbstractIdentifiable implements Module {
    protected AbstractModule() {
        super();
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
