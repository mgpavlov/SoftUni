package cresla.entities.modules.absorberModules;

public class CooldownSystem extends AbsorbingModuleAbstract{
    public CooldownSystem(/*int id, */int heatAbsorbing) {
        super(/*id, */heatAbsorbing);
    }
}
