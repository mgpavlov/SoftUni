package hell.entities.heroes;

public class Barbarian extends AbstractHero {
    public Barbarian(String name) {
        super(name);
    }
}
