package hell.entities.heroes;

public class Assassin extends AbstractHero {
    public Assassin(String name) {
        super(name);
    }
}
