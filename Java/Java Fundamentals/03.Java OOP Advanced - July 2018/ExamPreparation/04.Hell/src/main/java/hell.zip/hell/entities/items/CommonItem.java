package hell.entities.items;

public class CommonItem extends AbstractItem {
}
