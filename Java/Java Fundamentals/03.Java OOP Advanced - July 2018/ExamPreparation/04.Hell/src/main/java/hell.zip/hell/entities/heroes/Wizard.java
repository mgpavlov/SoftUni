package hell.entities.heroes;

public class Wizard extends AbstractHero {
    public Wizard(String name) {
        super(name);
    }
}
