package app.contracts;

public interface Specialist {

    void setSpecial(Special special);

    Special getSpecial();

}
