package app.contracts;

public interface Executable {

    void execute() throws IllegalAccessException;
}
