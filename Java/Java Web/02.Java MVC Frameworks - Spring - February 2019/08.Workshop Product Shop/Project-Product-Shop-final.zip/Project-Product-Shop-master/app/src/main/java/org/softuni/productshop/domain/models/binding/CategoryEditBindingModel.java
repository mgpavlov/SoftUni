package org.softuni.productshop.domain.models.binding;

public class CategoryEditBindingModel {

    private String name;

    public CategoryEditBindingModel() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
