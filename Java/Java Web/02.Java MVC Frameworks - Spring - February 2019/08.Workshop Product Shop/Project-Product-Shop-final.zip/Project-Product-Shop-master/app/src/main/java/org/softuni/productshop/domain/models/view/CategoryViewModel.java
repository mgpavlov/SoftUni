package org.softuni.productshop.domain.models.view;

public class CategoryViewModel {

    private String id;
    private String name;

    public CategoryViewModel() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
