package entities;

public enum PredictionEnum {
    HOME_TEAM_WIN, DRAW_GAME, AWAY_TEAM_WIN
}
