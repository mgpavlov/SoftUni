package products.dto.utilities;

public class CategoryIdDto {

    private long id;

    public CategoryIdDto() {
    }

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
