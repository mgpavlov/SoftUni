package cars.dto.utilities;

public class SaleIdDto {

    private long id;

    public SaleIdDto() {
    }

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
