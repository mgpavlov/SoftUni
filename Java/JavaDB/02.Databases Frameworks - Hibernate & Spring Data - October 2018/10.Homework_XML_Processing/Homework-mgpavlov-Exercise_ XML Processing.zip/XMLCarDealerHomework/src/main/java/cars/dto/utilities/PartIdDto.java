package cars.dto.utilities;

public class PartIdDto {

    private long id;

    public PartIdDto() {
    }

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
