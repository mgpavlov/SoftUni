package cars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarDealerMain {
    public static void main(final String[] args) {
        SpringApplication.run(CarDealerMain.class, args);
    }
}
