package cars.dto.utilities;

public class PartPriceUtilityDto {

    private double price;

    public PartPriceUtilityDto() {
    }

    public double getPrice() {
        return this.price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
