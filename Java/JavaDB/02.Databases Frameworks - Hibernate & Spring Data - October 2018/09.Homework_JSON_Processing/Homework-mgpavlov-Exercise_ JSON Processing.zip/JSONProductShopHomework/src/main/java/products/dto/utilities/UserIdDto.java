package products.dto.utilities;

public class UserIdDto {

    private long id;

    public UserIdDto() {
    }

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
