package game_store.model.enums;

public enum Role {
    ADMIN, USER
}
