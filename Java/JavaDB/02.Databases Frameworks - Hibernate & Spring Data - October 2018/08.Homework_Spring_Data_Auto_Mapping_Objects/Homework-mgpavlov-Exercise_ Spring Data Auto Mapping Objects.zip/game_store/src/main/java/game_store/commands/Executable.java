package game_store.commands;

public interface Executable {

    String execute(String... args);

}
